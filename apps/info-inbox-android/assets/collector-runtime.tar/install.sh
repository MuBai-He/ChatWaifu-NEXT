#!/system/bin/sh
set -eu
umask 077
[ "$(id -u)" = 0 ] || { echo 'Run this installer with Root.' >&2; exit 1; }
PACKAGE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BASE=/data/adb/wechat-collector
if [ -f "$BASE/collector.sh" ]; then
    /system/bin/sh "$BASE/collector.sh" stop
fi
mkdir -p "$BASE"
chmod 700 "$BASE"
cp -R "$PACKAGE/bin" "$PACKAGE/lib" "$BASE/"
cp "$PACKAGE/collector.sh" "$BASE/collector.sh"
cp "$PACKAGE/provenance.json" "$BASE/provenance.json"
chmod 700 "$BASE/bin" "$BASE/lib" "$BASE/bin/sqlcipher" "$BASE/collector.sh"
export LD_LIBRARY_PATH=$BASE/lib

if [ ! -f "$BASE/config.sh" ]; then
    # This automatic derivation was verified on the connected WeChat 8.0.78 device.
    # It is a compatibility probe, not a guarantee for other WeChat versions.
    SOURCE_DB=${WECHAT_SOURCE_DB:-}
    if [ -z "$SOURCE_DB" ]; then
        SOURCES=$(find /data/user/0/com.tencent.mm/MicroMsg -maxdepth 2 -name EnMicroMsg.db)
        [ "$(printf '%s\n' "$SOURCES" | sed '/^$/d' | wc -l)" = 1 ] || {
            echo 'Specify WECHAT_SOURCE_DB when zero or multiple account databases are found.' >&2
            exit 1
        }
        SOURCE_DB=$SOURCES
    fi
    ACCOUNT_ID=$(basename "$(dirname "$SOURCE_DB")")
    case "$ACCOUNT_ID" in ''|*[!0-9a-f]*) echo 'Unsupported account directory.' >&2; exit 1 ;; esac
    [ "$SOURCE_DB" = "/data/user/0/com.tencent.mm/MicroMsg/$ACCOUNT_ID/EnMicroMsg.db" ] || exit 1
    DB_KEY=${WECHAT_DB_KEY:-}
    if [ -z "$DB_KEY" ]; then
        UIN=$(sed -n 's/.*name="default_uin"[^>]*value="\([0-9-]*\)".*/\1/p' /data/user/0/com.tencent.mm/shared_prefs/system_config_prefs.xml)
        [ -n "$UIN" ] || { echo 'Automatic key derivation is unavailable.' >&2; exit 1; }
        DB_KEY=$(printf '%s' "1234567890ABCDEF$UIN" | md5sum | cut -c1-7)
        unset UIN
    fi
    case "$DB_KEY" in ''|*[!0-9a-f]*) echo 'Invalid key format.' >&2; exit 1 ;; esac
    [ "${#DB_KEY}" = 7 ] || exit 1
    # Validate without writing to the original database or putting the key in argv.
    if ! "$BASE/bin/sqlcipher" -readonly -batch -bail "$SOURCE_DB" >/dev/null 2> "$BASE/key-check.log" <<SQL
PRAGMA key='$DB_KEY';
PRAGMA cipher_compatibility=3;
PRAGMA cipher_page_size=1024;
PRAGMA kdf_iter=4000;
PRAGMA cipher_use_hmac=OFF;
SELECT count(*) FROM message;
SQL
    then
        echo 'The candidate key did not decrypt this database; installation stopped.' >&2
        exit 1
    fi
    printf "SOURCE_DB='%s'\nACCOUNT_ID='%s'\nDB_KEY='%s'\n" "$SOURCE_DB" "$ACCOUNT_ID" "$DB_KEY" > "$BASE/config.sh"
    chmod 600 "$BASE/config.sh"
    unset DB_KEY
fi
/system/bin/sh "$BASE/collector.sh" once
/system/bin/sh "$BASE/collector.sh" start
echo 'Installed. Nothing was added to boot startup.'
